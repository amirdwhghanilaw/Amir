#!/usr/bin/env bash
# Downloads Tailwind / Font Awesome / Vazirmatn into assets/www/vendor so the app
# works offline. Every step is independent: if a download fails, the matching
# CDN link in index.html is simply left untouched.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WWW="$ROOT/app/src/main/assets/www"
HTML="$WWW/index.html"
V="$WWW/vendor"
mkdir -p "$V/css" "$V/webfonts" "$V/fonts"

dl() { curl -fsSL --retry 2 --max-time 90 -o "$2" "$1" && [ -s "$2" ]; }

# 1) Tailwind (play build)
if dl "https://cdn.tailwindcss.com/3.4.17" "$V/tailwind.js"; then
  sed -i 's#https://cdn.tailwindcss.com#vendor/tailwind.js#' "$HTML"
  echo "tailwind: bundled"
else
  rm -f "$V/tailwind.js"; echo "tailwind: kept CDN"
fi

# 2) Font Awesome 6.5.1 (css + the three woff2 files it needs)
FA="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1"
fa_ok=1
dl "$FA/css/all.min.css" "$V/css/all.min.css" || fa_ok=0
for f in fa-solid-900 fa-regular-400 fa-brands-400; do
  dl "$FA/webfonts/$f.woff2" "$V/webfonts/$f.woff2" || fa_ok=0
done
if [ "$fa_ok" = 1 ]; then
  sed -i 's#https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css#vendor/css/all.min.css#' "$HTML"
  echo "fontawesome: bundled"
else
  echo "fontawesome: kept CDN"
fi

# 3) Vazirmatn variable font
if dl "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2" "$V/fonts/Vazirmatn.woff2"; then
  cat > "$V/vazirmatn.css" <<'CSS'
@font-face{font-family:'Vazirmatn';src:url('fonts/Vazirmatn.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap;}
CSS
  sed -i 's#<link href="https://fonts.googleapis.com/css2?family=Vazirmatn[^>]*>#<link rel="stylesheet" href="vendor/vazirmatn.css">#' "$HTML"
  echo "vazirmatn: bundled"
else
  rm -f "$V/fonts/Vazirmatn.woff2"; echo "vazirmatn: kept CDN"
fi
exit 0
