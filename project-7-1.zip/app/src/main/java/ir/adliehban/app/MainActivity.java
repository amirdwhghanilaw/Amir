package ir.adliehban.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.os.Build;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hosts the lawyer-assistant web app (assets/www) in a WebView and exposes the
 * phone calendar to it through {@link CalendarBridge} as window.AndroidCalendar.
 *
 * The bundled pages are served from the virtual https origin APP_HOST so that
 * localStorage, fonts and audio behave like on a normal secure website.
 */
public class MainActivity extends Activity {

    private static final String APP_HOST = "appassets.local";
    private static final int REQ_CALENDAR = 101;
    private static final int REQ_FILE = 102;
    private static final int REQ_ALL = 103;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        webView.addJavascriptInterface(new CalendarBridge(this), "AndroidCalendar");
        webView.addJavascriptInterface(new AlarmBridge(this), "AndroidAlarms");
        webView.addJavascriptInterface(new FileBridge(this), "AndroidFiles");
        AlarmReceiver.ensureChannel(this);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) {
                    return loadAsset(u.getPath());
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("https://" + APP_HOST + "/index.html");
    }

    private WebResourceResponse loadAsset(String path) {
        if (path == null || path.equals("/") || path.isEmpty()) {
            path = "/index.html";
        }
        try {
            InputStream in = getAssets().open("www" + path);
            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse(mimeFor(path), "UTF-8", 200, "OK", headers, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<String, String>(),
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mimeFor(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    /** Called from the JS bridge (any thread). */
    void requestCalendarPermission() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                requestPermissions(new String[]{
                        Manifest.permission.READ_CALENDAR,
                        Manifest.permission.WRITE_CALENDAR}, REQ_CALENDAR);
            }
        });
    }

    boolean hasCalendarPermission() {
        return checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    /** Asks (once, in one go) for the calendar and the notification permissions. */
    void requestAllPermissions() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                List<String> need = new ArrayList<>();
                if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                    need.add(Manifest.permission.READ_CALENDAR);
                }
                if (checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                    need.add(Manifest.permission.WRITE_CALENDAR);
                }
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    need.add("android.permission.POST_NOTIFICATIONS");
                }
                if (need.isEmpty()) {
                    reportPermissionState();
                } else {
                    requestPermissions(need.toArray(new String[0]), REQ_ALL);
                }
            }
        });
    }

    private void reportPermissionState() {
        boolean notify = true;
        if (Build.VERSION.SDK_INT >= 33) {
            notify = checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        }
        webView.evaluateJavascript(
                "window.__onCalendarPermission && window.__onCalendarPermission(" + hasCalendarPermission() + ");"
                        + "window.__onAlarmPermission && window.__onAlarmPermission(" + notify + ");", null);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == REQ_ALL) {
            reportPermissionState();
            return;
        }
        if (code != REQ_CALENDAR) return;
        boolean ok = results.length > 0;
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        }
        webView.evaluateJavascript(
                "window.__onCalendarPermission && window.__onCalendarPermission(" + ok + ")", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCallback != null) {
            filePathCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
        }
    }

    private void leaveApp() {
        super.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        // Close the in-app modal first; otherwise leave the app.
        webView.evaluateJavascript(
                "(function(){try{return (window.__handleBack&&window.__handleBack())?'handled':'exit';}"
                        + "catch(e){return 'exit';}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"\"handled\"".equals(value)) {
                            leaveApp();
                        }
                    }
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
