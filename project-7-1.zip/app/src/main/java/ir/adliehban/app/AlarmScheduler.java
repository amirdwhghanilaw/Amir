package ir.adliehban.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Schedules the automatic reminders (session / legal-deadline alarms) with the system AlarmManager
 * and remembers them so they can be restored after a phone restart.
 */
final class AlarmScheduler {

    static final String ACTION = "ir.adliehban.app.ALARM";
    private static final String PREFS = "adlieh_alarms";
    private static final String STORE = "items";

    private AlarmScheduler() {
    }

    static boolean canScheduleExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    private static Intent intentFor(Context c, String key) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.fromParts("alarm", key, null));
        return i;
    }

    static void schedule(Context c, String key, long when, String title, String text) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = intentFor(c, key);
        i.putExtra("key", key);
        i.putExtra("title", title);
        i.putExtra("text", text);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        try {
            if (canScheduleExact(c)) {
                PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void cancel(Context c, String key) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, intentFor(c, key),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (pi != null) {
            if (am != null) am.cancel(pi);
            pi.cancel();
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONObject load(Context c) {
        try {
            return new JSONObject(prefs(c).getString(STORE, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void save(Context c, JSONObject o) {
        prefs(c).edit().putString(STORE, o.toString()).apply();
    }

    static void forget(Context c, String key) {
        JSONObject m = load(c);
        m.remove(key);
        save(c, m);
    }

    /** items: [{key, when, title, text}] becomes the complete set of pending alarms. Returns how many are scheduled. */
    static int replaceAll(Context c, JSONArray items) {
        JSONObject old = load(c);
        JSONObject fresh = new JSONObject();
        long now = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            String key = it.optString("key", "");
            long when = it.optLong("when", 0);
            if (key.isEmpty() || when <= now + 1000) continue;
            String title = it.optString("title", "");
            String text = it.optString("text", "");
            try {
                fresh.put(key, new JSONObject().put("when", when).put("title", title).put("text", text));
            } catch (Exception e) {
                continue;
            }
            schedule(c, key, when, title, text);
            n++;
        }
        Iterator<String> keys = old.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            if (!fresh.has(k)) cancel(c, k);
        }
        save(c, fresh);
        return n;
    }

    /** Called after a phone restart or an app update (the system forgets all alarms then). */
    static void rescheduleAll(Context c) {
        JSONObject map = load(c);
        JSONObject keep = new JSONObject();
        long now = System.currentTimeMillis();
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            JSONObject v = map.optJSONObject(k);
            if (v == null) continue;
            long when = v.optLong("when", 0);
            if (when > now + 1000) {
                schedule(c, k, when, v.optString("title", ""), v.optString("text", ""));
                try {
                    keep.put(k, v);
                } catch (Exception ignored) {
                }
            }
        }
        save(c, keep);
    }
}
