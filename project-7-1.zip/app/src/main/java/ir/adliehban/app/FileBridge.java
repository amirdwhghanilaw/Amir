package ir.adliehban.app;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Stores the lawyer's PDF / Word files inside the app and opens them with the phone's viewers. */
public class FileBridge {

    private final MainActivity activity;

    FileBridge(MainActivity activity) {
        this.activity = activity;
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "docs");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static boolean validId(String id) {
        return id != null && id.matches("[A-Za-z0-9_-]{1,80}");
    }

    /** Appends (or starts) a file from base64 pieces sent by the page. */
    @JavascriptInterface
    public boolean writeChunk(String id, String base64, boolean append) {
        if (!validId(id)) return false;
        try {
            byte[] data = Base64.decode(base64 == null ? "" : base64, Base64.DEFAULT);
            FileOutputStream out = new FileOutputStream(new File(dir(activity), id), append);
            try {
                out.write(data);
            } finally {
                out.close();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean exists(String id) {
        return validId(id) && new File(dir(activity), id).isFile();
    }

    @JavascriptInterface
    public boolean delete(String id) {
        if (!validId(id)) return false;
        File f = new File(dir(activity), id);
        return !f.exists() || f.delete();
    }

    /** Returns OK, NOT_FOUND, NO_APP or ERROR. */
    @JavascriptInterface
    public String open(String id, String name, String mime) {
        if (!exists(id)) return "NOT_FOUND";
        String fileName = (name == null || name.isEmpty()) ? id : name;
        Uri uri = new Uri.Builder()
                .scheme("content")
                .authority(DocProvider.AUTHORITY)
                .appendPath(id)
                .appendPath(fileName)
                .build();
        final Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime);
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        final String[] result = {"OK"};
        final CountDownLatch latch = new CountDownLatch(1);
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    activity.startActivity(view);
                } catch (ActivityNotFoundException e) {
                    result[0] = "NO_APP";
                } catch (Exception e) {
                    result[0] = "ERROR";
                }
                latch.countDown();
            }
        });
        try {
            latch.await(3, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return result[0];
    }
}
