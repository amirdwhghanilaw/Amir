package ir.adliehban.app;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

/** JavaScript-visible control of the automatic phone alarms (window.AndroidAlarms). */
public class AlarmBridge {

    private final MainActivity activity;

    AlarmBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public String status() {
        boolean notify = true;
        NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) notify = nm.areNotificationsEnabled();
        try {
            return new JSONObject()
                    .put("notify", notify)
                    .put("exact", AlarmScheduler.canScheduleExact(activity))
                    .put("calendar", activity.hasCalendarPermission())
                    .put("sdk", Build.VERSION.SDK_INT)
                    .toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void requestPermissions() {
        activity.requestAllPermissions();
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 31) {
            i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + activity.getPackageName()));
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()));
        }
        launch(i);
    }

    @JavascriptInterface
    public void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()));
        }
        launch(i);
    }

    private void launch(final Intent i) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    activity.startActivity(i);
                } catch (Exception ignored) {
                }
            }
        });
    }

    /** json: [{key, when, title, text}] -> the full list of alarms that should exist. */
    @JavascriptInterface
    public int replaceAll(String json) {
        try {
            return AlarmScheduler.replaceAll(activity, new JSONArray(json));
        } catch (Exception e) {
            return -1;
        }
    }

    /** Rings in a few seconds so the user can check that alarms work on this phone. */
    @JavascriptInterface
    public boolean test() {
        AlarmReceiver.ensureChannel(activity);
        AlarmScheduler.schedule(activity, "test", System.currentTimeMillis() + 8000L,
                "🔔 تست آلارم عدلیه‌بان",
                "اگر این زنگ را می‌شنوید، آلارم جلسه‌ها و مواعد روی این گوشی درست کار می‌کند.");
        return true;
    }
}
