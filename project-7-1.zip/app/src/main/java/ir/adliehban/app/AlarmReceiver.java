package ir.adliehban.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

/** Fires when a scheduled reminder is due: posts a loud, repeating alarm notification. */
public class AlarmReceiver extends BroadcastReceiver {

    static final String CHANNEL_ID = "adlieh_alarm_v1";
    private static final long[] PATTERN = new long[]{0, 700, 350, 700, 350, 700};

    @Override
    public void onReceive(Context c, Intent intent) {
        String key = intent.getStringExtra("key");
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        if (key == null) key = "alarm";
        if (title == null || title.isEmpty()) title = "یادآوری عدلیه‌بان";
        if (text == null) text = "";
        AlarmScheduler.forget(c, key);
        show(c, key, title, text);
    }

    private static Uri alarmSound() {
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        return sound;
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "آلارم جلسات و مواعد",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("زنگ هشدار جلسات دادگاه و مواعد قانونی");
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        ch.setSound(alarmSound(), aa);
        ch.enableVibration(true);
        ch.setVibrationPattern(PATTERN);
        ch.enableLights(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(ch);
    }

    private static Notification.Builder builder(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(c, CHANNEL_ID);
        }
        return new Notification.Builder(c);
    }

    static void show(Context c, String key, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        ensureChannel(c);

        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, key.hashCode(), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        // What the lock screen shows (no client / case details)
        Notification.Builder pub = builder(c);
        pub.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("یادآوری عدلیه‌بان")
                .setContentText("یک جلسه یا موعد قانونی نزدیک است");

        Notification.Builder b = builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(openPi)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setPublicVersion(pub.build())
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);

        if (Build.VERSION.SDK_INT >= 26) {
            b.setTimeoutAfter(180000L); // stop ringing by itself after 3 minutes
        } else {
            b.setPriority(Notification.PRIORITY_MAX);
            b.setSound(alarmSound(), AudioManager.STREAM_ALARM);
            b.setVibrate(PATTERN);
            b.setDefaults(Notification.DEFAULT_LIGHTS);
        }

        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT; // repeat the sound until the notification is opened or dismissed
        nm.notify(key.hashCode(), n);
    }
}
